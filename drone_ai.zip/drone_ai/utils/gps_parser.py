"""
DRONE AI — GPS Parser
Reads NMEA sentences from a GPS module and extracts lat/lon/alt.
"""

import threading
import time
from dataclasses import dataclass, field
from datetime import datetime

try:
    import pynmea2
except ImportError:
    pynmea2 = None

from utils.serial_helper import SerialLink
from utils.logger import get_logger
from config import settings

log = get_logger("gps")


@dataclass
class GPSFix:
    latitude: float = 0.0
    longitude: float = 0.0
    altitude: float = 0.0
    speed_knots: float = 0.0
    satellites: int = 0
    has_fix: bool = False
    timestamp: str = ""


class GPSReader:
    """Background thread that continuously parses GPS data."""

    def __init__(self):
        self._link = SerialLink(settings.GPS_PORT, settings.GPS_BAUD, name="GPS")
        self._fix = GPSFix()
        self._lock = threading.Lock()
        self._running = False
        self._thread: threading.Thread | None = None

    @property
    def fix(self) -> GPSFix:
        with self._lock:
            return GPSFix(**vars(self._fix))  # return a copy

    def start(self):
        if not self._link.connect():
            log.warning("GPS not available — running without GPS")
            return
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        log.info("GPS reader started")

    def stop(self):
        self._running = False
        self._link.disconnect()

    def _loop(self):
        while self._running:
            line = self._link.read_line()
            if line:
                self._parse(line)
            time.sleep(0.05)

    def _parse(self, sentence: str):
        if pynmea2 is None:
            return
        try:
            msg = pynmea2.parse(sentence)
            with self._lock:
                if isinstance(msg, pynmea2.types.talker.GGA):
                    if msg.latitude and msg.longitude:
                        self._fix.latitude = msg.latitude
                        self._fix.longitude = msg.longitude
                        self._fix.altitude = float(msg.altitude or 0)
                        self._fix.satellites = int(msg.num_sats or 0)
                        self._fix.has_fix = int(msg.gps_qual or 0) > 0
                        self._fix.timestamp = datetime.now().isoformat()
                elif isinstance(msg, pynmea2.types.talker.RMC):
                    if msg.spd_over_grnd:
                        self._fix.speed_knots = float(msg.spd_over_grnd)
        except pynmea2.ParseError:
            pass
