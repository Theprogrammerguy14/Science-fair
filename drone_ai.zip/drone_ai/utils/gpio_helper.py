"""
DRONE AI — GPIO Helper (Debian Trixie / lgpio)
Manages all Raspberry Pi GPIO: LEDs, buzzer, kill switch, motor PWM.

Uses lgpio — the modern replacement for pigpio and RPi.GPIO on
Debian Trixie and newer Raspberry Pi OS.
"""

import threading
import time
from utils.logger import get_logger
from config import settings

log = get_logger("gpio_helper")

# Try importing lgpio (Trixie standard)
try:
    import lgpio
    HAS_LGPIO = True
except ImportError:
    HAS_LGPIO = False
    log.warning("lgpio not available — running in simulation mode")


class GPIOManager:
    """Centralized GPIO management using lgpio."""

    def __init__(self):
        self._handle = None  # lgpio chip handle
        self._buzzer_active = False
        self._kill_callback = None
        self._kill_monitor_running = False

    def setup(self):
        """Initialize all GPIO pins."""
        if not HAS_LGPIO:
            log.info("GPIO simulated — no hardware pins")
            return

        try:
            self._handle = lgpio.gpiochip_open(0)
            log.info("lgpio chip opened successfully")
        except Exception as e:
            log.error(f"Cannot open GPIO chip: {e}")
            log.error("Try running with sudo, or check /dev/gpiochip0 permissions")
            self._handle = None
            return

        # Output pins: LEDs and buzzer
        for pin in (settings.LED_STATUS, settings.LED_DETECTION,
                    settings.LED_WARNING, settings.BUZZER_PIN):
            lgpio.gpio_claim_output(self._handle, pin, 0)

        # Kill switch: input with pull-up
        lgpio.gpio_claim_input(self._handle, settings.KILL_SWITCH_PIN,
                               lgpio.SET_PULL_UP)

        log.info("GPIO pins initialized (lgpio)")

    def cleanup(self):
        """Release all GPIO resources."""
        if self._handle is not None:
            self._kill_monitor_running = False
            # Turn everything off
            for pin in (settings.LED_STATUS, settings.LED_DETECTION,
                        settings.LED_WARNING, settings.BUZZER_PIN):
                try:
                    lgpio.gpio_write(self._handle, pin, 0)
                except Exception:
                    pass
            # Stop all motors
            self.stop_all_motors()
            lgpio.gpiochip_close(self._handle)
            self._handle = None
            log.info("GPIO cleaned up")

    # ── LEDs ─────────────────────────────────────
    def set_led(self, pin: int, on: bool):
        if self._handle is not None:
            lgpio.gpio_write(self._handle, pin, 1 if on else 0)

    def led_status(self, on: bool):
        self.set_led(settings.LED_STATUS, on)

    def led_detection(self, on: bool):
        self.set_led(settings.LED_DETECTION, on)

    def led_warning(self, on: bool):
        self.set_led(settings.LED_WARNING, on)

    def blink_led(self, pin: int, times: int = 3, interval: float = 0.2):
        """Non-blocking LED blink."""
        def _blink():
            for _ in range(times):
                self.set_led(pin, True)
                time.sleep(interval)
                self.set_led(pin, False)
                time.sleep(interval)
        threading.Thread(target=_blink, daemon=True).start()

    # ── Buzzer ───────────────────────────────────
    def buzzer_on(self):
        if self._handle is not None:
            lgpio.gpio_write(self._handle, settings.BUZZER_PIN, 1)
        self._buzzer_active = True

    def buzzer_off(self):
        if self._handle is not None:
            lgpio.gpio_write(self._handle, settings.BUZZER_PIN, 0)
        self._buzzer_active = False

    def buzzer_beep(self, duration: float = 0.5, times: int = 3):
        """Non-blocking beep pattern."""
        def _beep():
            for _ in range(times):
                self.buzzer_on()
                time.sleep(duration)
                self.buzzer_off()
                time.sleep(duration * 0.5)
        threading.Thread(target=_beep, daemon=True).start()

    # ── Kill Switch ──────────────────────────────
    def register_kill_switch(self, callback):
        """
        Register a callback for the physical kill switch.
        lgpio doesn't have edge callbacks like RPi.GPIO,
        so we poll in a background thread.
        """
        self._kill_callback = callback
        self._kill_monitor_running = True
        threading.Thread(target=self._kill_switch_monitor, daemon=True).start()
        log.info("Kill switch monitor started on GPIO %d", settings.KILL_SWITCH_PIN)

    def _kill_switch_monitor(self):
        """Poll the kill switch pin every 50ms."""
        prev_state = 1  # pull-up means default HIGH
        while self._kill_monitor_running:
            if self._handle is not None:
                state = lgpio.gpio_read(self._handle, settings.KILL_SWITCH_PIN)
                # Detect falling edge (HIGH → LOW = button pressed)
                if prev_state == 1 and state == 0:
                    log.critical("KILL SWITCH PRESSED")
                    if self._kill_callback:
                        self._kill_callback()
                prev_state = state
            time.sleep(0.05)

    # ── Motor PWM (via lgpio servo pulses) ───────
    def set_motor_us(self, pin: int, pulse_us: int):
        """
        Set ESC pulse width in microseconds (1000–2000).
        Uses lgpio.tx_servo() for hardware-timed servo pulses.
        
        Args:
            pin:      BCM GPIO pin number
            pulse_us: Pulse width (1000=off, 1500=mid, 2000=full)
        """
        pulse_us = max(settings.ESC_MIN_US, min(settings.ESC_MAX_US, pulse_us))
        if self._handle is not None:
            try:
                # tx_servo(handle, gpio, pulse_width_us, servo_freq, offset)
                # frequency=50 Hz is standard for ESCs (20ms period)
                lgpio.tx_servo(self._handle, pin, pulse_us, 50)
            except Exception as e:
                log.error(f"Motor PWM error on GPIO {pin}: {e}")
        else:
            log.debug(f"[SIM] Motor GPIO {pin} → {pulse_us} µs")

    def stop_motor(self, pin: int):
        """Stop a motor (set pulse to 0 = no signal)."""
        if self._handle is not None:
            try:
                lgpio.tx_servo(self._handle, pin, 0, 50)
            except Exception:
                pass

    def stop_all_motors(self):
        """Emergency — kill all motors immediately."""
        for name, pin in settings.MOTOR_PINS.items():
            self.stop_motor(pin)
        log.info("All motors stopped")

    @property
    def is_ready(self) -> bool:
        return self._handle is not None
