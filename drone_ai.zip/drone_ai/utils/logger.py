"""
DRONE AI — Timestamped Logger
Creates per-mission log files and streams to console.
"""

import logging
import os
from datetime import datetime
from config import settings


def get_logger(name: str) -> logging.Logger:
    """Return a logger that writes to both console and a mission log file."""
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger  # already configured

    level = getattr(logging, settings.LOG_LEVEL, logging.INFO)
    logger.setLevel(level)

    fmt = logging.Formatter(
        "[%(asctime)s] %(levelname)-7s | %(name)-20s | %(message)s",
        datefmt="%H:%M:%S",
    )

    # Console handler
    ch = logging.StreamHandler()
    ch.setLevel(level)
    ch.setFormatter(fmt)
    logger.addHandler(ch)

    # File handler (one file per day)
    os.makedirs(settings.LOG_DIR, exist_ok=True)
    today = datetime.now().strftime("%Y-%m-%d")
    fh = logging.FileHandler(
        os.path.join(settings.LOG_DIR, f"mission_{today}.log")
    )
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(fmt)
    logger.addHandler(fh)

    return logger
