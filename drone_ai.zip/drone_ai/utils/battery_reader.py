"""
DRONE AI — Battery Reader
Reads battery voltage via MCP3008 ADC connected to Pi's SPI bus.
If no ADC is available, falls back to a simulated voltage.

Wiring: LiPo+ → voltage divider (4:1) → MCP3008 CH0 → Pi SPI
"""

import time
import threading
from utils.logger import get_logger
from config import settings

log = get_logger("battery")

try:
    import spidev
    HAS_SPI = True
except ImportError:
    HAS_SPI = False
    log.warning("spidev not available — battery voltage will be simulated")


class BatteryReader:
    """Reads battery voltage from MCP3008 ADC over SPI."""

    def __init__(self):
        self._spi = None
        self._voltage = settings.BATTERY_FULL_VOLTAGE  # start assuming full
        self._lock = threading.Lock()
        self._running = False

    def start(self):
        """Initialize SPI and start background reading."""
        if HAS_SPI:
            try:
                self._spi = spidev.SpiDev()
                self._spi.open(0, 0)          # SPI bus 0, chip select 0
                self._spi.max_speed_hz = 1_000_000
                log.info("MCP3008 ADC connected on SPI0")
            except Exception as e:
                log.warning(f"SPI init failed: {e} — using simulated voltage")
                self._spi = None
        
        self._running = True
        threading.Thread(target=self._read_loop, daemon=True).start()

    def stop(self):
        self._running = False
        if self._spi:
            self._spi.close()

    @property
    def voltage(self) -> float:
        with self._lock:
            return self._voltage

    def _read_loop(self):
        """Read voltage every 500ms."""
        while self._running:
            if self._spi:
                raw = self._read_adc(settings.BATTERY_ADC_CHANNEL)
                # MCP3008 gives 0–1023 for 0–3.3V reference
                adc_voltage = (raw / 1023.0) * 3.3
                actual_voltage = adc_voltage * settings.BATTERY_VOLTAGE_DIVIDER
                with self._lock:
                    self._voltage = round(actual_voltage, 2)
            else:
                # Simulation: slowly drain from full
                with self._lock:
                    self._voltage = max(
                        settings.BATTERY_CRITICAL_VOLTAGE,
                        self._voltage - 0.001
                    )
            time.sleep(0.5)

    def _read_adc(self, channel: int) -> int:
        """Read a single channel from MCP3008."""
        cmd = [1, (8 + channel) << 4, 0]
        result = self._spi.xfer2(cmd)
        value = ((result[1] & 3) << 8) + result[2]
        return value
